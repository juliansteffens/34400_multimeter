# Multimeter Control

This python package provides an API for controlling Agilent 34400 series measurement devices through the pyVISA package

## Installation

For installing this package run the following command:

```bash
pip install agilent34400multimeter